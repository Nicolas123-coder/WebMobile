import TwitterPost from "./components/TwitterPost/TwitterPost";

function App() {
  return (
    <div className="App">
      <TwitterPost />
    </div>
  );
}

export default App;
