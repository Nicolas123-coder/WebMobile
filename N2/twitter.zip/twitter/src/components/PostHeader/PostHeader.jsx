import React from "react";
import "./PostHeader.css"

function PostHeader(props) {

  const { name, user, checked } = props;

  return (
    <div className="post-header">
      <img
        src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8e/Visit_of_Tim_Cook_to_the_European_Commission_-_P061904-946789.jpg/300px-Visit_of_Tim_Cook_to_the_European_Commission_-_P061904-946789.jpg"
        alt="Foto de Perfil"
        className="profile-picture"
      />
      <div className="profile-div">
        <div className="profile_name">
          {name}
          <div className="profile_account">{user}</div>
        </div>
        {checked && (
          <div className="profile_checked">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/Twitter_Verified_Badge.svg/800px-Twitter_Verified_Badge.svg.png" />
          </div>
        )}
        <img
          src={
            "https://upload.wikimedia.org/wikipedia/commons/thumb/6/6f/Logo_of_Twitter.svg/1245px-Logo_of_Twitter.svg.png"
          }
          alt="Logo do Twitter"
          className="twitter-logo"
        />
      </div>
    </div>
  );
}

export default PostHeader;
