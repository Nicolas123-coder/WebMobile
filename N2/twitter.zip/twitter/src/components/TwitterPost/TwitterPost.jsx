import React, { useState } from "react";
import "./TwitterPost.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart, faComment } from "@fortawesome/free-solid-svg-icons";
import PostHeader from "../PostHeader/PostHeader";

const post = {
  name: "Tim Cook",
  user: "@tim_cook",
  checked: true,
  message: "Happy Easter! 🐇🐣",
};

let numberOfLikes = 9634;

function TwitterPost() {
  const [curtido, setCurtido] = useState(false);

  const handleCurtir = () => {
    if (curtido === true) {
      numberOfLikes -= 1;
      setCurtido(!curtido);
      return;
    }
    setCurtido(!curtido);
    numberOfLikes += 1;
  };

  const iconColor = curtido ? "red" : "#555";

  return (
    <div className="main-div">
      <div className="post-container">
        <PostHeader name={post.name} user={post.user} checked={post.checked} />
        <div className="post-info">{post.message}</div>
        <div className="post-datetime-info">
          11:55 - 09/04/23 - <strong>1,4M </strong> Views
        </div>
        <hr />
        <div className="bookmarks">
          <strong>27 </strong> Bookmarks
        </div>
        <hr />
        <div className="btn-container">
          <button onClick={handleCurtir} className="btn">
            <FontAwesomeIcon
              icon={faHeart}
              style={{
                color: iconColor,
                fontSize: "large",
                marginRight: "5px",
              }}
            />{" "}
          </button>
          {numberOfLikes}
          <FontAwesomeIcon
            icon={faComment}
            style={{
              color: "#555",
              fontSize: "large",
              marginLeft: "20px",
              marginRight: "5px",
              fontWeight: "100",
            }}
          />{" "}
          540
        </div>
      </div>
    </div>
  );
}

export default TwitterPost;
